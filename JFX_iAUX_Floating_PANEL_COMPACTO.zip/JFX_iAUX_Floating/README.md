# iAUX LGTZ Floating App

## Logo exacto
El workflow descarga la imagen original desde:
https://jfx-sensi.neocities.org/iAUX%20LGTZ.png

Se usa el mismo archivo como:
- Icono de la app instalada.
- Imagen de la burbuja flotante.
- Logo del encabezado del panel flotante.
- Logo de la pantalla principal.

## Compilar desde GitHub en iPhone
1. Reemplaza los archivos del repositorio con el contenido de esta carpeta, manteniendo `.github/workflows/build-apk.yml`.
2. Abre la pestaña Actions.
3. Selecciona `Build iAUX LGTZ APK`.
4. Pulsa `Run workflow`.
5. Espera a que termine en verde.
6. En la ejecución, baja a Artifacts y descarga `iAUX-LGTZ-debug-apk`.

El workflow descarga el PNG original antes de compilar. Por eso necesita acceso a Internet durante la ejecución.


### Panel compacto
El encabezado del panel incluye un botón con el símbolo ▱ para alternar entre tamaño normal y compacto. En tamaño compacto la ventana ocupa aproximadamente 66% del ancho y 46% del alto de la pantalla. El contenido web también se muestra con zoom reducido.
